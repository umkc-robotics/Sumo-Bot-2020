#include "Arduino.h"
#include "Sight.h"


Sight::Sight()
{
}