#ifndef Sight_h
#define Sight_h

#include <Arduino.h>

class Sight
{
	public:
		Sight();
};


#endif
