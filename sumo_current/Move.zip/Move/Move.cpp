#include "Arduino.h"
#include "Move.h"

Move::Move()
{
  powerValue = 120;
  pwm1 = 11; // Power to right motor
  pwm2 = 10; // Power to left motor
  dir1 = 12; // Direction of right motor (low is forward)
  dir2 = 13; // Direction of left motor (low is forward)
  // bool true = HIGH
  // bool false = LOW
}

Move* Move::power(int setPower)
{
  powerValue = setPower;
  return this;
}

void Move::set(int right, int left, bool dirR, bool dirL)
{
  analogWrite(pwm1, right);
  analogWrite(pwm2, left);
  digitalWrite(dir1, dirR);   
  digitalWrite(dir2, dirL);
}

void Move::forward()
{
  analogWrite(pwm1, powerValue);
  analogWrite(pwm2, powerValue);
  digitalWrite(dir1, LOW);   
  digitalWrite(dir2, LOW);
}
void Move::backward()
{
	analogWrite(pwm1, powerValue);
	analogWrite(pwm2, powerValue);
	digitalWrite(dir1, HIGH);
	digitalWrite(dir2, HIGH);

}
void Move::left()
{
  analogWrite(pwm1, powerValue*2);
  analogWrite(pwm2, powerValue*2);
	digitalWrite(dir1, LOW);
  digitalWrite(dir2, HIGH);
}
void Move::right()
{
  analogWrite(pwm1, powerValue*2);
  analogWrite(pwm2, powerValue*2);
  digitalWrite(dir1, HIGH);
	digitalWrite(dir2, LOW);

}
void Move::halt()
{
  analogWrite(pwm1, 0);
  analogWrite(pwm2, 0);
  digitalWrite(dir1, LOW);   
  digitalWrite(dir2, LOW);
}

	
